import "./NotFound.css";


export default function NotFound() {
    return (
        <div className="notFound">
            <div>404</div>
            <div>Not found</div>
        </div>
    )
}