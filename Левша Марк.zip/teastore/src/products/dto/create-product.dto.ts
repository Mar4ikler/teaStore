export class CreateProductDto {
  product_name: string;
  description: string;
  productImage: string;
  price: number;
  category_id: number;
  brewingTemperature: string;
}
