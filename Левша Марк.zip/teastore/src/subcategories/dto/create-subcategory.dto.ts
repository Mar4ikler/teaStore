export class CreateSubcategoryDto {
  category_name: string;
  parent: number;
}
