export class CreateReviewDto {
  user_id: number;
  review_text: string;
  date: string;
}
