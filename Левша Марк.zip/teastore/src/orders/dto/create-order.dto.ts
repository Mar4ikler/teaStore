export class CreateOrderDto {
  user_id: number;
  product_id: number;
  quantity: number;
  price: number;
  orderDate: string;
  isBuying: string;
}
